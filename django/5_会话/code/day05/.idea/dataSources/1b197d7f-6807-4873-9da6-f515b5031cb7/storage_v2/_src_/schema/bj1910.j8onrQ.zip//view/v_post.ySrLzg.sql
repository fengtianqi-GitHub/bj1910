create view v_post as
select `p`.`id`         AS `id`,
       `p`.`tid`        AS `tid`,
       `p`.`authorid`   AS `authorid`,
       `p`.`title`      AS `title`,
       `p`.`content`    AS `content`,
       `p`.`addtime`    AS `addtime`,
       `p`.`addip`      AS `addip`,
       `p`.`classid`    AS `classid`,
       `p`.`replycount` AS `replycount`,
       `p`.`hits`       AS `hits`,
       `p`.`istop`      AS `istop`,
       `p`.`elite`      AS `elite`,
       `p`.`ishot`      AS `ishot`,
       `p`.`rate`       AS `rate`,
       `p`.`attachment` AS `attachment`,
       `p`.`isdel`      AS `isdel`,
       `p`.`style`      AS `style`,
       `p`.`isdisplay`  AS `isdisplay`,
       `u`.`username`   AS `username`,
       `c`.`classname`  AS `classname`
from ((`bj1910`.`bbs_user` `u` join `bj1910`.`bbs_post` `p`)
         join `bj1910`.`bbs_category` `c`)
where ((`u`.`uid` = `p`.`authorid`) and (`p`.`classid` = `c`.`cid`));

