create view v_2 as
select `p`.`id`         AS `id`,
       `p`.`authorid`   AS `authorid`,
       `p`.`title`      AS `title`,
       `p`.`content`    AS `content`,
       `p`.`addtime`    AS `addtime`,
       `p`.`istop`      AS `istop`,
       `p`.`elite`      AS `elite`,
       `p`.`ishot`      AS `ishot`,
       `p`.`replycount` AS `replycount`,
       `p`.`classid`    AS `classid`,
       `p`.`hits`       AS `hits`,
       `p`.`isdel`      AS `isdel`,
       `c`.`classname`  AS `classname`,
       `u`.`username`   AS `username`
from ((`bj1910`.`bbs_user` `u` join `bj1910`.`bbs_post` `p`)
         join `bj1910`.`bbs_category` `c`)
where ((`u`.`uid` = `p`.`authorid`) and (`c`.`cid` = `p`.`classid`));

