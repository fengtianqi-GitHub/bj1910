create view v_3 as
select `p`.`id`        AS `id`,
       `p`.`title`     AS `uname`,
       `p`.`content`   AS `title`,
       `u`.`username`  AS `content`,
       `c`.`classname` AS `cname`
from ((`bj1910`.`bbs_post` `p` join `bj1910`.`bbs_user` `u`)
         join `bj1910`.`bbs_category` `c`)
where ((`u`.`uid` = `p`.`authorid`) and (`p`.`classid` = `c`.`cid`));

