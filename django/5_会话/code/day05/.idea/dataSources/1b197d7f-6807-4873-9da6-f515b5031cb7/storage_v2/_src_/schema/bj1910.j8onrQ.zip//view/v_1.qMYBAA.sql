create view v_1 as
select `p`.`id` AS `id`, `p`.`title` AS `title`, `p`.`content` AS `content`, `c`.`classname` AS `classname`
from (`bj1910`.`bbs_category` `c`
         join `bj1910`.`bbs_post` `p` on ((`c`.`cid` = `p`.`classid`)));

